*Regras de Associação para Pizzarias
